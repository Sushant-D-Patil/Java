package com.kiranacademy.Studentexam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentExamApplicationTests {

	@Test
	void contextLoads() {
	}

}
