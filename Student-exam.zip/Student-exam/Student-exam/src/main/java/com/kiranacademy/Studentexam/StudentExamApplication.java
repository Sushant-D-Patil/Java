package com.kiranacademy.Studentexam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;


@SpringBootApplication
@ComponentScan("com")
@EntityScan("com")
public class StudentExamApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentExamApplication.class, args);
		//Object o=new Object();
		//o.clone();
		System.out.println();
	}

}
