package com.kiranacademy.controller;

import java.io.File;
import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.kiranacademy.dao.RegistrationDAO;
import com.kiranacademy.entity.User;

@Controller
public class RegistrationController {

	@Autowired
	RegistrationDAO dao;
	
	@RequestMapping ("register")
	public String register() {
		return "register";
	}

	@RequestMapping("save")
	public ModelAndView saveRegistrationData(User user,HttpServletRequest request) throws Exception
	{
		MultipartFile image=user.getImage();
		
		String filename=image.getOriginalFilename();
		
		String foldername=request.getServletContext().getRealPath("images");
		
		image.transferTo(new File(foldername,filename));
		
		user.setImagepath("/images/"+filename);
		
		dao.saveToDB(user);
		
		ModelAndView modelAndView=new ModelAndView();
		modelAndView.setViewName("login");
		modelAndView.addObject("message","Registration Successful.please login now");
		return modelAndView;
		
	}
	
	
	
	
	
	
	
}
