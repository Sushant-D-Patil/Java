package com.kiranacademy.controller;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.kiranacademy.entity.Question;





@Controller
public class QuestionManagementController {

	@Autowired
	SessionFactory factory;

	@RequestMapping("addQuestion")
	public ModelAndView addQuestion(Question question)
	{
		Session session = factory.openSession();
		
		Transaction tx = session.beginTransaction();
		
			session.save(question);
		
		tx.commit(); // model-data which should be displayed on jsp page
		
		ModelAndView modelAndView = new ModelAndView();
		
		modelAndView.setViewName("questionmanagement");
		
		modelAndView.addObject("message","question addded");
		
		return modelAndView;
		
	}
	
	@RequestMapping("updateQuestion")
	public ModelAndView updateQuestion(Question question)
	{
		Session session = factory.openSession();
		
		
		
		Transaction tx = session.beginTransaction();
		
		
		Query<Question> query=session.createQuery("update Question set qtext=:qtext, op1=:op1,op2=:op2,op3=:op3,op4=:op4,answer=:answer where qno=:qno and subject=:subject");
		
		
		query.setParameter("qtext",question.qtext);
		query.setParameter("qno",question.qno);
		query.setParameter("subject",question.subject);
		query.setParameter("op1",question.op1);
		query.setParameter("op2",question.op2);
		query.setParameter("op3",question.op3);
		query.setParameter("op4",question.op4);
		query.setParameter("answer",question.answer);
		
		query.executeUpdate();
			
		
		tx.commit(); // model-data which should be displayed on jsp page
		
		ModelAndView modelAndView = new ModelAndView();
		
		modelAndView.setViewName("questionmanagement");
		
		modelAndView.addObject("message","question updated");
		
		return modelAndView;
		
	}
	
	
	@RequestMapping("viewQuestion")
	public ModelAndView viewQuestion(Integer qno,String subject)
	{
		Session session = factory.openSession();
		
		// session.load(Student.class,qno)
		
		Query<Question> query=session.createQuery("from Question where qno=:qno and subject=:subject");
		query.setParameter("qno",qno);
		query.setParameter("subject",subject);
		
		List<Question> list=query.list();
		
		Question question=list.get(0);
		
		ModelAndView modelAndView=new ModelAndView();
		modelAndView.setViewName("questionmanagement");
		modelAndView.addObject("question",question);
		
		
		return modelAndView;
	}
	
	
// delete from questions where qno=1 and subject='maths'
	
	@RequestMapping("deleteQuestion")
	public ModelAndView deleteQuestion(Question question)
	{
		Session session = factory.openSession();
		
		Transaction tx = session.beginTransaction();
		
		Query<Question> query=session.createQuery("delete from Question  where qno=:qno and subject=:subject");
		
		query.setParameter("qno",question.qno);
		query.setParameter("subject",question.subject);
		
		query.executeUpdate();
		
		tx.commit();
		
		ModelAndView modelAndView = new ModelAndView();
		
		modelAndView.setViewName("questionmanagement");
		
		modelAndView.addObject("message","question deleted");
		
		return modelAndView;
		
		
	}
	
}
