package com.kiranacademy.controller;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.kiranacademy.dao.LoginDAO;
import com.kiranacademy.dao.QuestionDAO;
import com.kiranacademy.entity.Answer;
import com.kiranacademy.entity.Question;
import com.kiranacademy.entity.User;

@Controller
public class LoginController {
	@Autowired
	LoginDAO dao;
	
	@Autowired 
	QuestionDAO qdao;
	
	@RequestMapping("login")
	public String login() {
		return "login";
	}
	
	
	@RequestMapping("/")
	public String menu() {
		return "menu";
	}
	
	@RequestMapping("admin")
	public String questionmanagement()
	{
		return "questionmanagement";  // here login is jsp page name
	}
	
	
	@RequestMapping ("validate")
	public ModelAndView validate(String username,String password,String subject,HttpServletRequest request) {
		
		User user=dao.getUser(username);
		
		ModelAndView modelAndView=new ModelAndView();
		HttpSession httpsession=request.getSession();
		
		if(user==null) {
			modelAndView.setViewName("login");
			modelAndView.addObject("message","Username is Wrong");
		}
		else if(user.getPassword().equals(password)) {
			
			modelAndView.setViewName("question");
			
			modelAndView.addObject("message","welcome "+username);
			modelAndView.addObject("photo",user.getImagepath());
			
			List<Question>list=qdao.getAllQuestions(subject);
			
			Question question=list.get(0);
			
			httpsession.setAttribute("question", question);
			httpsession.setAttribute("questions", list);
			httpsession.setAttribute("username", username);
			httpsession.setAttribute("qno", 0);
			httpsession.setAttribute("score", 0);
			
			
			HashMap<Integer,Answer>  hashmap=new HashMap<>();
			
			httpsession.setAttribute("submittedDetails",hashmap);
			
			
			System.out.println(question);
			
			
			 //modelAndView.addObject("questions",list);
		}
		else {
			modelAndView.setViewName("login");
			modelAndView.addObject("message","Wrong Password");
		}
		return modelAndView;
	}
	
	
	public ModelAndView logout(HttpServletRequest request) {
		HttpSession httpsession=request.getSession();
		
		System.out.println(httpsession.getAttribute("message"));
		
		httpsession.invalidate();
		
		ModelAndView modelAndView = new ModelAndView();
		
		modelAndView.addObject("message","session is invalidated");
		
		modelAndView.setViewName("login");
		
		return modelAndView;
	}
	
	

}
