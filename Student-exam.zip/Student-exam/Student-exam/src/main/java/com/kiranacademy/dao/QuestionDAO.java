package com.kiranacademy.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.kiranacademy.entity.Question;
import com.kiranacademy.entity.Questions;

@Repository
public class QuestionDAO {
	
	@Autowired
	SessionFactory factory;
	
	public List<Question> getAllQuestions(String subject){
		Session session=factory.openSession();
		
	Criteria criteria=session.createCriteria(Question.class);
	
	criteria.add(Restrictions.eq("subject", subject));
	
	return criteria.list();
		
	}
	
	public List<Questions> getAllQuestions2(String sub)
	{

		ArrayList<Questions> arraylist=new ArrayList<>();
		
		
		try
		{

	    Class.forName("com.mysql.cj.jdbc.Driver");
		Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3307/mydata","root","root");
		Statement statement=connection.createStatement();
		ResultSet resultset=statement.executeQuery("select * from question where subject='"+sub+"'");
		
		while(resultset.next()) 
		{
		
			System.out.println("inside loop");
			
					int qno=resultset.getInt("qno");
					String qtext=resultset.getString("qtext");
					

					String op1=resultset.getString("op1");

					String op2=resultset.getString("op2");

					String op3=resultset.getString("op3");

					String op4=resultset.getString("op4");
					
					
					String[] options= {op1,op2,op3,op4};

		
					Questions questions=new Questions();
					
					questions.setQno(qno);
					questions.setQtext(qtext);

					questions.setOptions(options);
					questions.setSubject(sub);
					questions.setAnswer(resultset.getString("answer"));
				
					arraylist.add(questions);	
					System.out.println("List from DAO " + arraylist);
					
		}

		}
		catch(Exception e)
		{
				e.printStackTrace();
		}
		
		
		return arraylist; 
		
	}

	

}
