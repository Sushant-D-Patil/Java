package com.kiranacademy.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.kiranacademy.entity.User;

@Repository
public class RegistrationDAO {
	
	@Autowired
	SessionFactory factory;
	
	public void saveToDB(User user) {
		Session session =factory.openSession();
		session.save(user);
		session.beginTransaction().commit();
	}

}
