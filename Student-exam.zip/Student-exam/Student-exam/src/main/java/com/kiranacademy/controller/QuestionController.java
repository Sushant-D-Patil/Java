package com.kiranacademy.controller;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.kiranacademy.entity.Answer;
import com.kiranacademy.entity.Question;

@Controller
public class QuestionController {

	
	@RequestMapping("endexam")
	public ModelAndView endexam(HttpServletRequest request)
	{
		 ModelAndView modelAndView =new ModelAndView();
		
		HttpSession httpSession=request.getSession();

		HashMap<Integer,Answer> hashmap=(HashMap<Integer, Answer>) httpSession.getAttribute("submittedDetails");
		
		System.out.println(hashmap);
		
		if(hashmap==null) {
			modelAndView.setViewName("login");
			return modelAndView;
		}
		Collection<Answer> collection=hashmap.values();
		
		for (Answer answer : collection) 
		{
				if(answer.getOption().equals(answer.getOriginalAnswer()))
				{

					 httpSession.setAttribute("score",(Integer) httpSession.getAttribute("score")+1);
					
				}
		}


		
		 
		 modelAndView.addObject("allanswers",collection);
		 
		 modelAndView.setViewName("score");
		 
		 modelAndView.addObject("score",(Integer)httpSession.getAttribute("score"));
		 
		 httpSession.invalidate();
		 
		return modelAndView;
		
	}
	
	
	@RequestMapping("next")
	public ModelAndView next(HttpServletRequest request,Answer answer) {
		

		HttpSession httpSession=request.getSession();
		
	
	if(request.getParameter("option")!=null)
	{
		HashMap<Integer,Answer> hashmap=(HashMap<Integer, Answer>) httpSession.getAttribute("submittedDetails");
		
		hashmap.put(answer.getQno(), answer);
		
		System.out.println(hashmap);
		
	}
		
	 List<Question> list=(List<Question>) httpSession.getAttribute("questions");
	 
	 ModelAndView modelAndView =new ModelAndView();
	 
	 modelAndView.setViewName("question");
	 
      if((Integer) httpSession.getAttribute("qno")<=list.size()-2)
      {
	
	 httpSession.setAttribute("qno",(Integer) httpSession.getAttribute("qno")+1);
		
	 Question question=list.get((Integer) httpSession.getAttribute("qno"));
	 
	 modelAndView.addObject("question",question);
	}
      else {
    	 
    	  modelAndView.addObject("message","questions over.click on previous button");
    	  modelAndView.addObject("question",list.get(list.size()-1));
      }
	 return modelAndView;
	}
	
	
	@RequestMapping("previous")
	public ModelAndView previous(HttpServletRequest request) {
		HttpSession httpsession=request.getSession();
		
		List<Question>list=(List<Question>) httpsession.getAttribute("questions");
		
		ModelAndView modelAndView= new ModelAndView();
		 modelAndView.setViewName("question");
		 
		 if((Integer)httpsession.getAttribute("qno")>0)
		 {
			 httpsession.setAttribute("qno",(Integer)httpsession.getAttribute("qno")-1);
			 Question question=list.get((Integer)httpsession.getAttribute("qno"));
			 
			// code to retrieve previous answer

				int qno=question.getQno(); // retrieve question number
						
				HashMap<Integer, Answer>  hashmap=(HashMap<Integer, Answer>) httpsession.getAttribute("submittedDetails");
				
	
				Answer answer=hashmap.get(qno);
				
				String previousAnswer="";
				
				if(answer!=null)
				{
					previousAnswer=answer.getOption();
				}

			 modelAndView.addObject("question",question);
			 modelAndView.addObject("previousAnswer",previousAnswer);
				
			 
		 }
		 else
		 {
			 modelAndView.addObject("message","questions over.click on next button");
			  modelAndView.addObject("question",list.get(0));
		 }
		 
		 
		return modelAndView;
	}
	
	
	
}

